To Contribute, add a feature and create a pull request to share your contribution with others.
